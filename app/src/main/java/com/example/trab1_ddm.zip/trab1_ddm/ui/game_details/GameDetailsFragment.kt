package com.example.trab1_ddm.ui.game_details

class GameDetailsFragment {
}